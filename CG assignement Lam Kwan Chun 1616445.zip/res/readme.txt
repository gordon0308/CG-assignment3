-- 3dvia.com   --

The zip file valerie1.obj.zip contains the following files :
- readme.txt
- valerie1.obj
- valerie1.mtl
- Mouth_Tongue_Tongue1Color.tga
- Mouth_LowerTeeth_LowerTeeth1Color.tga
- Head_UpperTeeth_UpperTeeth1Color.tga
- Head_Hair_Hair1Color.tga
- Head_Hair_Hair1Bump.tga
- EyeR_EyelashR_Eyelash1RColor.tga
- EyeR_EyeballR_EyeballRColor.tga
- EyeL_EyelashL_Eyelash1LColor.tga
- EyeL_EyeballL_EyeballLColor.tga
- Body_Shirt_DecolleteColor.tga
- Body_Shirt_DecolleteBump.tga


-- Model information --

Model Name : valerie1
Author : Quidam
Publisher : wismo

You can view this model here :
http://www.3dvia.com/content/26354A1C2E001224
More models about this author :
http://www.3dvia.com/wismo


-- Attached license --

A license is attached to the valerie1 model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
